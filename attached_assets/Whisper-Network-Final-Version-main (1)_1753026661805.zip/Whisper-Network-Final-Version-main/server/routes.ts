import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema, insertReplySchema, insertAdminSchema, insertUserSchema, insertReactionSchema, insertNotificationSchema, insertFollowSchema } from "@shared/schema";
import { z } from "zod";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string): Promise<boolean> {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Authentication routes for users
  // Check username availability
  app.get("/api/auth/check-username/:username", async (req, res) => {
    try {
      const { username } = req.params;
      
      // Check if username exists in users table
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        res.json({ available: false, message: "Username already taken by a Silent Messenger" });
        return;
      }
      
      // Check if username exists in admins table
      const existingAdmin = await storage.getAdminByUsername(username);
      if (existingAdmin) {
        res.json({ available: false, message: "Username already taken by a Whisper Listener" });
        return;
      }
      
      res.json({ available: true, message: "Username is available" });
    } catch (error) {
      console.error("Username check error:", error);
      res.status(500).json({ message: "Failed to check username" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Check if username already exists in both tables
      const existingUser = await storage.getUserByUsername(username);
      const existingAdmin = await storage.getAdminByUsername(username);
      
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists as Silent Messenger" });
      }
      
      if (existingAdmin) {
        return res.status(400).json({ message: "Username already exists as Whisper Listener" });
      }
      
      // Hash password and create user
      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({ username, password: hashedPassword });
      
      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Error registering user:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      const user = await storage.getUserByUsername(username);
      if (!user || !await comparePasswords(password, user.password)) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      if (!user.isActive) {
        return res.status(401).json({ message: "Account is disabled" });
      }
      
      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error logging in user:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Admin authentication routes
  app.post("/api/auth/admin-login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      const admin = await storage.getAdminByUsername(username);
      if (!admin) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Special handling for ZEKE001 - password should be "ZEKE001"
      if (username === "ZEKE001") {
        if (password !== "ZEKE001") {
          return res.status(401).json({ message: "Invalid credentials" });
        }
        if (!admin.isActive) {
          return res.status(401).json({ message: "Account is disabled" });
        }
        const { password: _, ...adminWithoutPassword } = admin;
        return res.json(adminWithoutPassword);
      }
      
      // For other admins, check password
      if (!admin.password || !await comparePasswords(password, admin.password)) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      if (!admin.isActive) {
        return res.status(401).json({ message: "Account is disabled" });
      }
      
      const { password: _, ...adminWithoutPassword } = admin;
      res.json(adminWithoutPassword);
    } catch (error) {
      console.error("Error logging in admin:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Create admin (only for existing admins)
  app.post("/api/admin/create", async (req, res) => {
    try {
      const { username, password, displayName, role } = req.body;
      
      // Check if admin already exists
      const existingAdmin = await storage.getAdminByUsername(username);
      if (existingAdmin) {
        return res.status(400).json({ message: "Admin username already exists" });
      }
      
      // Hash password if provided
      const hashedPassword = password ? await hashPassword(password) : null;
      
      const admin = await storage.createAdmin({
        username,
        password: hashedPassword,
        displayName,
        role: role || "admin",
      });
      
      const { password: _, ...adminWithoutPassword } = admin;
      res.status(201).json(adminWithoutPassword);
    } catch (error) {
      console.error("Error creating admin:", error);
      res.status(500).json({ message: "Failed to create admin" });
    }
  });

  // Get all admins
  app.get("/api/admin/list", async (req, res) => {
    try {
      const admins = await storage.getAllAdmins();
      const adminsWithoutPasswords = admins.map(({ password, ...admin }) => admin);
      res.json(adminsWithoutPasswords);
    } catch (error) {
      console.error("Error fetching admins:", error);
      res.status(500).json({ message: "Failed to fetch admins" });
    }
  });

  // Update admin status
  app.patch("/api/admin/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      const { isActive } = req.body;
      
      const admin = await storage.updateAdminStatus(parseInt(id), isActive);
      const { password: _, ...adminWithoutPassword } = admin;
      res.json(adminWithoutPassword);
    } catch (error) {
      console.error("Error updating admin status:", error);
      res.status(500).json({ message: "Failed to update admin status" });
    }
  });

  // Get all public messages
  app.get("/api/messages/public", async (req, res) => {
    try {
      const messages = await storage.getPublicMessages();
      
      // Enhance messages with reaction counts and reactions
      const messagesWithReactions = await Promise.all(
        messages.map(async (message) => {
          let reactions: any[] = [];
          let reactionCount = 0;
          
          try {
            reactions = await storage.getMessageReactions(message.id);
            reactionCount = reactions.length;
          } catch (error) {
            // Skip if reactions table doesn't exist
          }

          return {
            ...message,
            reactions,
            reactionCount,
          };
        })
      );

      res.json(messagesWithReactions);
    } catch (error) {
      console.error("Error fetching public messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Search public messages
  app.get("/api/messages/search", async (req, res) => {
    try {
      const { q } = req.query;
      const query = typeof q === 'string' ? q : '';
      const messages = await storage.searchPublicMessages(query);
      res.json(messages);
    } catch (error) {
      console.error("Error searching messages:", error);
      res.status(500).json({ message: "Failed to search messages" });
    }
  });

  app.get("/api/messages/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const message = await storage.getMessageById(parseInt(id));
      if (!message) {
        res.status(404).json({ message: "Message not found" });
        return;
      }
      
      // Add reaction data
      let reactions: any[] = [];
      let reactionCount = 0;
      
      try {
        reactions = await storage.getMessageReactions(message.id);
        reactionCount = reactions.length;
      } catch (error) {
        // Skip if reactions table doesn't exist
      }

      res.json({
        ...message,
        reactions,
        reactionCount,
      });
    } catch (error) {
      console.error("Error fetching message:", error);
      res.status(500).json({ message: "Failed to fetch message" });
    }
  });

  // Get all private messages (admin only)
  app.get("/api/messages/private", async (req, res) => {
    try {
      const messages = await storage.getPrivateMessages();
      res.json(messages);
    } catch (error) {
      console.error("Error fetching private messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Get messages by category
  app.get("/api/messages/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const messages = await storage.getMessagesByCategory(category);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages by category:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Get messages by recipient
  app.get("/api/messages/recipient/:recipient", async (req, res) => {
    try {
      const { recipient } = req.params;
      const messages = await storage.getMessagesByRecipient(recipient);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages by recipient:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Get available recipients
  app.get("/api/recipients", async (req, res) => {
    try {
      const recipients = await storage.getRecipients();
      res.json(recipients);
    } catch (error) {
      console.error("Error fetching recipients:", error);
      res.status(500).json({ message: "Failed to fetch recipients" });
    }
  });

  // Create new message
  app.post("/api/messages", async (req, res) => {
    try {
      const validatedData = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage(validatedData);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid message data", errors: error.errors });
        return;
      }
      console.error("Error creating message:", error);
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  // Create new reply
  app.post("/api/replies", async (req, res) => {
    try {
      const validatedData = insertReplySchema.parse(req.body);
      const reply = await storage.createReply(validatedData);
      res.status(201).json(reply);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid reply data", errors: error.errors });
        return;
      }
      console.error("Error creating reply:", error);
      res.status(500).json({ message: "Failed to create reply" });
    }
  });

  app.delete("/api/replies/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteReply(parseInt(id));
      res.json({ message: "Reply deleted successfully" });
    } catch (error) {
      console.error("Error deleting reply:", error);
      res.status(500).json({ message: "Failed to delete reply" });
    }
  });

  // Delete message (admin only)
  app.delete("/api/messages/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteMessage(parseInt(id));
      res.json({ message: "Message deleted successfully" });
    } catch (error) {
      console.error("Error deleting message:", error);
      res.status(500).json({ message: "Failed to delete message" });
    }
  });

  app.post("/api/warnings", async (req, res) => {
    try {
      const { replyId, messageId, reason, userId } = req.body;
      
      // Store warning in database (you could extend schema for warnings table)
      console.log(`Warning sent for reply ${replyId} on message ${messageId} to user ${userId}: ${reason}`);
      
      // In a real app, this would send notifications/emails to users
      res.json({ 
        message: "Warning sent successfully",
        details: `Warning sent for inappropriate content: ${reason}` 
      });
    } catch (error) {
      console.error("Error sending warning:", error);
      res.status(500).json({ message: "Failed to send warning" });
    }
  });

  // Update message visibility (make private message public)
  app.patch("/api/messages/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { isPublic } = req.body;
      const message = await storage.updateMessageVisibility(parseInt(id), isPublic);
      res.json(message);
    } catch (error) {
      console.error("Error updating message visibility:", error);
      res.status(500).json({ message: "Failed to update message" });
    }
  });

  // Admin management routes
  app.post("/api/admins", async (req, res) => {
    try {
      const validatedData = insertAdminSchema.parse(req.body);
      const admin = await storage.createAdmin(validatedData);
      // Don't return password in response
      const { password, ...adminWithoutPassword } = admin;
      res.status(201).json(adminWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid admin data", errors: error.errors });
        return;
      }
      console.error("Error creating admin:", error);
      res.status(500).json({ message: "Failed to create admin" });
    }
  });

  app.get("/api/admins", async (req, res) => {
    try {
      const admins = await storage.getAllAdmins();
      // Don't return passwords in response
      const adminsWithoutPasswords = admins.map(({ password, ...admin }) => admin);
      res.json(adminsWithoutPasswords);
    } catch (error) {
      console.error("Error fetching admins:", error);
      res.status(500).json({ message: "Failed to fetch admins" });
    }
  });

  app.patch("/api/admins/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { isActive } = req.body;
      const admin = await storage.updateAdminStatus(parseInt(id), isActive);
      const { password, ...adminWithoutPassword } = admin;
      res.json(adminWithoutPassword);
    } catch (error) {
      console.error("Error updating admin status:", error);
      res.status(500).json({ message: "Failed to update admin status" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = await storage.getUserByUsername(username);
      
      if (!user || !user.isActive) {
        res.status(401).json({ message: "Invalid credentials" });
        return;
      }

      const isValidPassword = await comparePasswords(password, user.password);
      if (!isValidPassword) {
        res.status(401).json({ message: "Invalid credentials" });
        return;
      }
      
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error during login:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/admin-login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const admin = await storage.getAdminByUsername(username);
      
      if (!admin || admin.password !== password || !admin.isActive) {
        res.status(401).json({ message: "Invalid credentials" });
        return;
      }
      
      const { password: _, ...adminWithoutPassword } = admin;
      res.json(adminWithoutPassword);
    } catch (error) {
      console.error("Error during admin login:", error);
      res.status(500).json({ message: "Admin login failed" });
    }
  });

  // User management routes
  app.get("/api/user/messages/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const messages = await storage.getUserMessages(parseInt(userId));
      res.json(messages);
    } catch (error) {
      console.error("Error fetching user messages:", error);
      res.status(500).json({ message: "Failed to fetch user messages" });
    }
  });

  app.delete("/api/users/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteUser(parseInt(id));
      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  app.get("/api/users/search", async (req, res) => {
    try {
      const { q } = req.query;
      const users = await storage.searchUsers(q as string || "");
      // Remove passwords from response
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      console.error("Error searching users:", error);
      res.status(500).json({ message: "Failed to search users" });
    }
  });

  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      // Remove passwords from response
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { isActive } = req.body;
      const user = await storage.updateUserStatus(parseInt(id), isActive);
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error updating user status:", error);
      res.status(500).json({ message: "Failed to update user status" });
    }
  });

  // User profile routes
  app.get("/api/users/:id/profile", async (req, res) => {
    try {
      const { id } = req.params;
      const profile = await storage.getUserProfile(parseInt(id));
      if (!profile) {
        return res.status(404).json({ message: "User not found" });
      }
      const { password, ...profileWithoutPassword } = profile;
      res.json(profileWithoutPassword);
    } catch (error) {
      console.error("Error fetching user profile:", error);
      res.status(500).json({ message: "Failed to fetch user profile" });
    }
  });

  app.get("/api/users/:id/messages", async (req, res) => {
    try {
      const { id } = req.params;
      const messages = await storage.getUserMessages(parseInt(id));
      res.json(messages);
    } catch (error) {
      console.error("Error fetching user messages:", error);
      res.status(500).json({ message: "Failed to fetch user messages" });
    }
  });

  // Reaction routes
  app.post("/api/messages/:id/reactions", async (req, res) => {
    try {
      const { id } = req.params;
      const messageId = parseInt(id);
      const { userId, adminId, type = "heart" } = req.body;

      // Check if user already reacted
      const existingReaction = await storage.getUserReaction(messageId, userId, adminId);
      if (existingReaction) {
        return res.status(400).json({ message: "You have already reacted to this message" });
      }

      // Add reaction
      const reaction = await storage.addReaction({
        messageId,
        userId: userId || null,
        adminId: adminId || null,
        type,
      });

      // Get message to find owner for notification
      const message = await storage.getMessageById(messageId);
      if (message && message.userId) {
        // Create notification for message owner
        const fromName = userId ? (await storage.getUserById(userId))?.username : 
                         adminId ? (await storage.getAdminByUsername("admin"))?.displayName : "Anonymous";
        
        await storage.createNotification({
          userId: message.userId,
          type: "reaction",
          messageId,
          fromUserId: userId || null,
          fromAdminId: adminId || null,
          content: `${fromName} reacted with ${type} to your message`,
          isRead: false,
        });
      }

      res.status(201).json(reaction);
    } catch (error) {
      console.error("Error adding reaction:", error);
      res.status(500).json({ message: "Failed to add reaction" });
    }
  });

  app.delete("/api/messages/:id/reactions", async (req, res) => {
    try {
      const { id } = req.params;
      const messageId = parseInt(id);
      const { userId, adminId } = req.body;

      await storage.removeReaction(messageId, userId, adminId);
      res.status(204).send();
    } catch (error) {
      console.error("Error removing reaction:", error);
      res.status(500).json({ message: "Failed to remove reaction" });
    }
  });

  app.get("/api/messages/:id/reactions", async (req, res) => {
    try {
      const { id } = req.params;
      const reactions = await storage.getMessageReactions(parseInt(id));
      res.json(reactions);
    } catch (error) {
      console.error("Error fetching reactions:", error);
      res.status(500).json({ message: "Failed to fetch reactions" });
    }
  });

  // Notification routes
  app.get("/api/notifications/user/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const notifications = await storage.getUserNotifications(parseInt(userId));
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching user notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.get("/api/notifications/admin/:adminId", async (req, res) => {
    try {
      const { adminId } = req.params;
      const notifications = await storage.getAdminNotifications(parseInt(adminId));
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching admin notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.patch("/api/notifications/:id/read", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.markNotificationAsRead(parseInt(id));
      res.status(204).send();
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.patch("/api/notifications/mark-all-read", async (req, res) => {
    try {
      const { userId, adminId } = req.body;
      await storage.markAllNotificationsAsRead(userId, adminId);
      res.status(204).send();
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ message: "Failed to mark all notifications as read" });
    }
  });

  // User profile endpoints
  app.get("/api/users/:id/profile", async (req, res) => {
    const userId = parseInt(req.params.id);
    const currentUserId = req.query.currentUserId ? parseInt(req.query.currentUserId as string) : undefined;
    
    if (!userId) {
      return res.status(400).json({ error: "Invalid user ID" });
    }

    try {
      const profile = await storage.getUserProfile(userId, currentUserId);
      if (!profile) {
        return res.status(404).json({ error: "User not found" });
      }

      // Don't return password
      const { password, ...profileWithoutPassword } = profile;
      res.json(profileWithoutPassword);
    } catch (error) {
      console.error("Error fetching user profile:", error);
      res.status(500).json({ error: "Failed to fetch user profile" });
    }
  });

  app.get("/api/users/:id/messages", async (req, res) => {
    const userId = parseInt(req.params.id);
    if (!userId) {
      return res.status(400).json({ error: "Invalid user ID" });
    }

    try {
      const messages = await storage.getUserMessages(userId);
      
      // Get reactions and replies for each message
      const messagesWithDetails = await Promise.all(
        messages.map(async (message) => {
          let reactionCount = 0;
          try {
            const reactions = await storage.getMessageReactions(message.id);
            reactionCount = reactions.length;
          } catch (error) {
            // Skip if reactions table doesn't exist yet
          }
          
          const replies = await storage.getRepliesByMessageId(message.id);
          return {
            ...message,
            reactionCount,
            replies: replies || [],
          };
        })
      );

      res.json(messagesWithDetails);
    } catch (error) {
      console.error("Error fetching user messages:", error);
      res.status(500).json({ error: "Failed to fetch user messages" });
    }
  });

  // Follow system endpoints
  app.post("/api/users/:id/follow", async (req, res) => {
    try {
      const followingId = parseInt(req.params.id);
      const { followerId } = req.body;
      
      if (!followingId || !followerId) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      if (followingId === followerId) {
        return res.status(400).json({ error: "Cannot follow yourself" });
      }

      // Check if already following
      const isAlreadyFollowing = await storage.isFollowing(followerId, followingId);
      if (isAlreadyFollowing) {
        return res.status(400).json({ error: "Already following this user" });
      }

      const follow = await storage.followUser(followerId, followingId);
      
      // Create notification for the followed user
      const follower = await storage.getUserById(followerId);
      if (follower) {
        await storage.createNotification({
          userId: followingId,
          type: "follow",
          fromUserId: followerId,
          content: `${follower.username} started following you`,
        });
      }

      res.json(follow);
    } catch (error) {
      console.error("Error following user:", error);
      res.status(500).json({ error: "Failed to follow user" });
    }
  });

  app.delete("/api/users/:id/follow", async (req, res) => {
    try {
      const followingId = parseInt(req.params.id);
      const { followerId } = req.body;
      
      if (!followingId || !followerId) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      await storage.unfollowUser(followerId, followingId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error unfollowing user:", error);
      res.status(500).json({ error: "Failed to unfollow user" });
    }
  });

  app.get("/api/users/:id/followers", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (!userId) {
        return res.status(400).json({ error: "Invalid user ID" });
      }

      const followers = await storage.getUserFollowers(userId);
      // Remove password from response
      const followersWithoutPassword = followers.map(({ password, ...user }) => user);
      res.json(followersWithoutPassword);
    } catch (error) {
      console.error("Error fetching followers:", error);
      res.status(500).json({ error: "Failed to fetch followers" });
    }
  });

  app.get("/api/users/:id/following", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (!userId) {
        return res.status(400).json({ error: "Invalid user ID" });
      }

      const following = await storage.getUserFollowing(userId);
      // Remove password from response
      const followingWithoutPassword = following.map(({ password, ...user }) => user);
      res.json(followingWithoutPassword);
    } catch (error) {
      console.error("Error fetching following:", error);
      res.status(500).json({ error: "Failed to fetch following" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
